class config:
    def __init__(self) -> None:
        self.table = 'DebtLineBOT'